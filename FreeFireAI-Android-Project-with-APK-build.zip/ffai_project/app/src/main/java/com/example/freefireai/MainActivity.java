package com.example.freefireai;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(13, 17, 30);
    private final int panel = Color.rgb(25, 32, 52);
    private final int accent = Color.rgb(255, 174, 0);
    private LinearLayout messages;
    private ScrollView chatScroll;
    private EditText input;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private static final int REQ_MIC = 41;

    // Configure this to your own HTTPS backend. Never put a private AI API key inside the APK.
    private static final String AI_ENDPOINT = "https://YOUR-SERVER.example/chat";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("ar"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                           result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(12));
        root.setBackgroundColor(bg);

        TextView title = new TextView(this);
        title.setText("🤖 مساعد حساسية فري فاير");
        title.setTextColor(accent);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, params(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("شات وصوت بالعربي • Samsung Galaxy Tab A7");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(6), 0, dp(12));
        root.addView(subtitle, params(-1, -2));

        chatScroll = new ScrollView(this);
        chatScroll.setFillViewport(true);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(dp(10), dp(10), dp(10), dp(10));
        messages.setBackgroundColor(panel);
        chatScroll.addView(messages);
        root.addView(chatScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        addMessage("المساعد", "أهلًا يا بطل! اكتب مشكلتك أو اضغط 🎙️ وتكلم. أقدر أساعدك في مراجعة قيم الحساسية والمشاكل اللي بتوصفها. النسخة دي فيها نصائح محلية، وربط الذكاء الاصطناعي الحقيقي يحتاج إعداد خادم آمن.", false, false);

        LinearLayout composer = new LinearLayout(this);
        composer.setOrientation(LinearLayout.HORIZONTAL);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(0, dp(10), 0, 0);

        input = new EditText(this);
        input.setSingleLine(false);
        input.setMinLines(1);
        input.setMaxLines(3);
        input.setHint("اكتب مشكلتك هنا...");
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setBackgroundTintList(ColorStateList.valueOf(accent));
        composer.addView(input, new LinearLayout.LayoutParams(0, -2, 1));

        Button mic = new Button(this);
        mic.setText("🎙️");
        mic.setContentDescription("تحدث");
        mic.setAllCaps(false);
        mic.setOnClickListener(v -> startVoice());
        composer.addView(mic, params(-2, -2));

        Button send = new Button(this);
        send.setText("إرسال");
        send.setAllCaps(false);
        send.setOnClickListener(v -> sendMessage());
        composer.addView(send, params(-2, -2));
        root.addView(composer, params(-1, -2));

        Button copy = new Button(this);
        copy.setText("نسخ إعدادات الحساسية");
        copy.setAllCaps(false);
        copy.setOnClickListener(v -> {
            String settings = "Free Fire - Samsung Galaxy Tab A7\nالعام: 165\nRed Dot: 155\nسكوب 2x: 145\nسكوب 4x: 125\nسكوب القناص: 80\nالنظرة الحرة: 130\nحجم زر الإطلاق: 48%";
            ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Free Fire settings", settings));
            Toast.makeText(this, "تم نسخ الإعدادات", Toast.LENGTH_SHORT).show();
        });
        root.addView(copy, params(-1, -2));

        TextView note = new TextView(this);
        note.setText("التطبيق لا يغيّر إعدادات اللعبة تلقائيًا ولا يضمن الهيدشوت. المساعد لا يرى اللعب مباشرةً؛ يحلل وصفك للمشكلة.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(12);
        note.setPadding(0, dp(8), 0, 0);
        root.addView(note, params(-1, -2));

        setContentView(root);
    }

    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "خدمة التعرف على الصوت غير متاحة على الجهاز.", Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        try {
            if (speechRecognizer != null) speechRecognizer.destroy();
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { Toast.makeText(MainActivity.this, "اتكلم دلوقتي...", Toast.LENGTH_SHORT).show(); }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onError(int error) { Toast.makeText(MainActivity.this, "ما سمعتش الكلام بوضوح. جرّب تاني.", Toast.LENGTH_SHORT).show(); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) {
                        input.setText(matches.get(0));
                        input.setSelection(input.length());
                    }
                }
                @Override public void onPartialResults(Bundle partialResults) {}
                @Override public void onEvent(int eventType, Bundle params) {}
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "قول مشكلة الحساسية");
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر تشغيل الميكروفون أو خدمة الصوت.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVoice();
        else if (requestCode == REQ_MIC) Toast.makeText(this, "لازم تسمح باستخدام الميكروفون لتتكلم مع التطبيق.", Toast.LENGTH_LONG).show();
    }

    private void sendMessage() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) return;
        addMessage("أنت", q, true, false);
        input.setText("");
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0);

        if (AI_ENDPOINT.contains("YOUR-SERVER.example")) {
            String reply = localAdvice(q);
            addMessage("المساعد", reply, false, true);
            return;
        }

        addMessage("المساعد", "ثواني، بفحص سؤالك...", false, false);
        new Thread(() -> {
            String reply;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection)new URL(AI_ENDPOINT).openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(12000);
                c.setReadTimeout(20000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                JSONObject body = new JSONObject();
                body.put("message", q);
                body.put("device", "Samsung Galaxy Tab A7");
                body.put("game", "Free Fire");
                try (OutputStream os = c.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                InputStream is = (c.getResponseCode() < 400) ? c.getInputStream() : c.getErrorStream();
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                byte[] data = new byte[4096]; int n;
                while ((n = is.read(data)) != -1) buffer.write(data, 0, n);
                JSONObject response = new JSONObject(new String(buffer.toByteArray(), StandardCharsets.UTF_8));
                reply = response.optString("reply", "الخادم لم يرجع ردًا مفهومًا.");
            } catch (Exception e) {
                reply = "مش قادر أوصل للمساعد أونلاين. راجع الإنترنت ورابط الخادم.";
            } finally { if (c != null) c.disconnect(); }
            final String finalReply = reply;
            runOnUiThread(() -> addMessage("المساعد", finalReply, false, true));
        }).start();
    }

    private String localAdvice(String q) {
        String s = q.toLowerCase(Locale.ROOT);
        if (s.contains("فوق الرأس") || s.contains("فوق راس") || s.contains("بيعدي فوق")) {
            return "لو السحب بيعدّي فوق الرأس، جرّب تقليل العام وRed Dot بمقدار 5 درجات فقط، واختبر سلاحًا واحدًا في ساحة التدريب قبل أي تعديل إضافي. مثال مبدئي: العام 160 وRed Dot 150.";
        }
        if (s.contains("الصدر") || s.contains("مش بيطلع") || s.contains("بطيء")) {
            return "لو التصويب بيقف عند الصدر، جرّب زيادة العام وRed Dot بمقدار 3 إلى 5 درجات، ثم اختبر سحبة قصيرة. لا تغيّر كل القيم مرة واحدة.";
        }
        if (s.contains("تقطيع") || s.contains("لاق") || s.contains("بطء")) {
            return "لو فيه تقطيع على Tab A7، جرّب Graphics على Smooth، اقفل التطبيقات الخلفية، واستخدم أعلى معدل إطارات مستقر متاح في اللعبة.";
        }
        if (s.contains("حساسية") || s.contains("إعدادات")) {
            return "إعداداتك المبدئية: العام 165، Red Dot 155، سكوب 2x 145، سكوب 4x 125، القناص 80، النظرة الحرة 130. عدّل قيمة واحدة كل مرة وسجّل النتيجة.";
        }
        return "اكتب اسم السلاح والمشكلة بالتحديد، مثل: «النقّار بيطلع فوق الرأس» أو «MP40 السحب بطيء». أقدر أحلل وصفك، لكن التطبيق لا يرى اللعب مباشرةً.";
    }

    private void addMessage(String who, String body, boolean user, boolean speak) {
        TextView bubble = new TextView(this);
        bubble.setText(who + "\n" + body);
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(15);
        bubble.setPadding(dp(12), dp(10), dp(12), dp(10));
        bubble.setBackgroundColor(user ? Color.rgb(47, 64, 91) : Color.rgb(37, 45, 66));
        LinearLayout.LayoutParams p = params(-1, -2);
        p.bottomMargin = dp(8);
        messages.addView(bubble, p);
        chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
        if (speak && ttsReady && tts != null) tts.speak(body, TextToSpeech.QUEUE_FLUSH, null, "assistant-reply");
    }

    @Override protected void onDestroy() {
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
